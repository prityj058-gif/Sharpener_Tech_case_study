#-- which age group has the highest churn rate. --#
 SELECT 
    Age_Group,
    COUNT(*) AS Total_Customers,
    SUM(CASE
        WHEN Churn_Status = 'Churned' THEN 1
        ELSE 0
    END) AS Churned_Customers,
    ROUND(SUM(CASE
                WHEN Churn_Status = 'Churned' THEN 1
                ELSE 0
            END) * 100.0 / COUNT(*),
            2) AS Churn_Rate
FROM
    boxify_customers_raw_data
GROUP BY Age_Group
ORDER BY Churn_Rate DESC;


#-- which location has the highest churn rate.--#
 SELECT
    Location,
    COUNT(*) AS Total_Customers,
    SUM(CASE
        WHEN Churn_Status = 'Churned' THEN 1
        ELSE 0
    END) AS Churned_Customers,
    ROUND(
        SUM(CASE
            WHEN Churn_Status = 'Churned' THEN 1
            ELSE 0
        END) * 100.0 / COUNT(*),
        2
    ) AS Churn_Rate
FROM boxify_customers_raw_data
GROUP BY Location
ORDER BY Churn_Rate DESC;
 

#-- which subscription type has the highest churn rate. --#
SELECT
    Subscription_Type,
    COUNT(*) AS Total_Customers,
    SUM(CASE
        WHEN Churn_Status = 'Churned' THEN 1
        ELSE 0
    END) AS Churned_Customers,
    ROUND(
        SUM(CASE
            WHEN Churn_Status = 'Churned' THEN 1
            ELSE 0
        END) * 100.0 / COUNT(*),
        2
    ) AS Churn_Rate
FROM boxify_customers_raw_data
GROUP BY Subscription_Type
ORDER BY Churn_Rate DESC;

#-- How does engagement level correlate with churn? --#
SELECT
    Engagement_Level,
    COUNT(*) AS Total_Customers,
    SUM(CASE
        WHEN Churn_Status = 'Churned' THEN 1
        ELSE 0
    END) AS Churned_Customers,
    ROUND(
        SUM(CASE
            WHEN Churn_Status = 'Churned' THEN 1
            ELSE 0
        END) * 100.0 / COUNT(*),
        2
    ) AS Churn_Rate,
    ROUND(AVG(Monthly_Logins), 2) AS Avg_Monthly_Logins,
    ROUND(AVG(Box_Interactions), 2) AS Avg_Box_Interactions
FROM boxify_customers_raw_data
GROUP BY Engagement_Level
ORDER BY Churn_Rate DESC;


#-- What is the average lifetime value of churned vs active customers? --#
SELECT
    Churn_Status,
    COUNT(*) AS Customer_Count,
    ROUND(AVG(Total_Revenue_INR), 2) AS Average_Lifetime_Value
FROM boxify_customers_raw_data
GROUP BY Churn_Status;

#-- Can you predict potential churners based on historical data? --#
SELECT
    Churn_Risk_Level,
    COUNT(*) AS Customer_Count,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM boxify_customers),
        2
    ) AS Percentage
FROM boxify_customers_raw_data
GROUP BY Churn_Risk_Level
ORDER BY Customer_Count DESC;


#-- What retention strategies should Boxify implement, including personalized offers or engagement tactics? --#
#Boxify should focus on targeted retention strategies for high-risk customers . Customers in the first 6 months should receive onboarding support and personalized offers. Low-engagement customers can be targeted with reminders, product recommendations, and interactive campaigns. Basic-plan customers can receive personalized upgrade or value-based offers. Customers with low satisfaction should receive feedback and service-recovery campaigns. These strategies can help reduce churn and improve customer loyalty.
  